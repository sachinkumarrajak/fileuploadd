﻿using DataAccess.Repository.IRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    [AllowAnonymous]
    public class UploadController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public UploadController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ReceiveMessage([FromBody] string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                return BadRequest("Message cannot be empty.");
            }

            // Process the received message (you can print it to the console here)
            System.Console.WriteLine($"Received message: {message}");

            return Ok("Message received successfully.");
        }

        [HttpPost]

       
        public async Task<IActionResult> UploadFile(int employeeId, IFormFile file)
        {
            if (await _unitOfWork.employee.UploadEmployeeFile(employeeId, file))
            {
                return RedirectToAction("Details", new { id = employeeId });
            }

            return RedirectToAction("Details", new { id = employeeId }); // You can handle the error scenario differently
        }
    }
}
