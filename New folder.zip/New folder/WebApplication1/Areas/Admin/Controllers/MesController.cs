﻿using DataAccess.Repository.IRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AllowAnonymous]
    public class MesController : Controller
    {

        private readonly IUnitOfWork _unitOfWork;

        public MesController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult PrintMessage()
        {
            Console.WriteLine("API received a message from WPF.");
            return Ok("Message received and printed.");
        }

        [HttpPost]


        public async Task<IActionResult> UploadFile(int employeeId, IFormFile file)
        {
            if (await _unitOfWork.employee.UploadEmployeeFile(employeeId, file))
            {
                return RedirectToAction("Details", new { id = employeeId });
            }

            return RedirectToAction("Details", new { id = employeeId }); // You can handle the error scenario differently
        }

        public async Task<IActionResult> UploadFile(int employeeId, IFormFile file, DateTime lastModifiedDate)
        {
            if (await _unitOfWork.employee.UploadEmployeeFile(employeeId, file, lastModifiedDate))
            {
                return RedirectToAction("Details", new { id = employeeId });
            }

            return RedirectToAction("Details", new { id = employeeId }); // You can handle the error scenario differently
        }
    }
}
