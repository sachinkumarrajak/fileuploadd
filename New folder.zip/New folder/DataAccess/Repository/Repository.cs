﻿
using DataAccess.Data;
using DbModel;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository.IRepository
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly ApplicationDbContext _db;
        internal DbSet<T> dbSet;

        public Repository(ApplicationDbContext db)
        {
            _db= db;
            //_db.ShoppingCarts.Include(u => u.Product).Include(u=>u.CoverType);
            this.dbSet= _db.Set<T>();
        }
        public void Add(T entity)
        {
            dbSet.Add(entity);
        }
        //includeProp - "Category,CoverType"
        public IEnumerable<T> GetAll(Expression<Func<T, bool>>? filter=null, string? includeProperties = null)
        {
            IQueryable<T> query = dbSet;
            if (filter != null)
            {
                query = query.Where(filter);
            }
            if (includeProperties != null)
            {
                foreach(var includeProp in includeProperties.Split(new char[] { ','}, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProp);
                }
            }
            return query.ToList();
        }
        public EmployeeFile GetEmployeeFileById(int id)
        {
            return _db.EmployeeFiles.FirstOrDefault(ef => ef.ID == id);
        }

        public Employee GetEmployeeWithFiles(int id)
        {
            return _db.Employees
                .Include(e => e.EmployeeFiles)
                .FirstOrDefault(e => e.ID == id);
        }
        //public async Task<bool> UploadEmployeeFile(int employeeId, IFormFile file)
        //{
        //    if (file == null || file.Length == 0)
        //    {
        //        return false;
        //    }

        //    var fileName = Path.GetFileName(file.FileName);
        //    var filePath = Path.Combine("wwwroot", "uploads", fileName); // Path to the wwwroot/uploads folder

        //    using (var stream = new FileStream(filePath, FileMode.Create))
        //    {
        //        await file.CopyToAsync(stream);
        //    }

        //    var employeeFile = new EmployeeFile
        //    {
        //        FileName = fileName,
        //        FilePath = filePath,
        //        EmployeeID = employeeId
        //    };

        //    _db.EmployeeFiles.Add(employeeFile);
        //    await _db.SaveChangesAsync();

        //    return true;
        //}
        //public async Task<bool> UploadEmployeeFile(int employeeId, IFormFile file)
        //{
        //    if (file == null || file.Length == 0)
        //    {
        //        return false;
        //    }

        //    var fileName = Path.GetFileName(file.FileName);
        //    var filePath = Path.Combine("wwwroot", "uploads", fileName); // Path to the wwwroot/uploads folder

        //    // Check if a file with the same name already exists
        //    var existingFile = await _db.EmployeeFiles.FirstOrDefaultAsync(e => e.FileName == fileName && e.EmployeeID == employeeId);

        //    if (existingFile != null)
        //    {
        //        // Delete the old file record and the associated file
        //        _db.EmployeeFiles.Remove(existingFile);
        //        await _db.SaveChangesAsync();
        //        File.Delete(existingFile.FilePath);
        //    }

        //    using (var stream = new FileStream(filePath, FileMode.Create))
        //    {
        //        await file.CopyToAsync(stream);
        //    }

        //    var employeeFile = new EmployeeFile
        //    {
        //        FileName = fileName,
        //        FilePath = filePath,
        //        EmployeeID = employeeId
        //    };

        //    _db.EmployeeFiles.Add(employeeFile);
        //    await _db.SaveChangesAsync();

        //    return true;
        //}


        public async Task<bool> UploadEmployeeFile(int employeeId, IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return false;
            }

            var fileName = Path.GetFileName(file.FileName);
            var employeeFolder = Path.Combine("wwwroot", "uploads", employeeId.ToString());

            // Create the employee-specific folder if it doesn't exist
            if (!Directory.Exists(employeeFolder))
            {
                Directory.CreateDirectory(employeeFolder);
            }
                       
            var filePath = Path.Combine(employeeFolder, fileName);
          //  DateTime fileCreatedDate = File.GetCreationTime(filePath);
            DateTime lastModifiedDate = File.GetLastWriteTime(filePath);
            // Check if a file with the same name already exists
            var existingFile = await _db.EmployeeFiles.FirstOrDefaultAsync(e => e.FileName == fileName && e.EmployeeID == employeeId);

            if (existingFile != null)
            {
                // Delete the old file record and the associated file
                _db.EmployeeFiles.Remove(existingFile);
                await _db.SaveChangesAsync();
                File.Delete(existingFile.FilePath);
            }

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var employeeFile = new EmployeeFile
            {
                FileName = fileName,
                FilePath = filePath,
                FileCreatedDate = lastModifiedDate,
                EmployeeID = employeeId
            };

            _db.EmployeeFiles.Add(employeeFile);
            await _db.SaveChangesAsync();

            return true;
        }


        public async Task<bool> UploadEmployeeFile(int employeeId, IFormFile file, DateTime lastModifiedDate)
        {
            if (file == null || file.Length == 0)
            {
                return false;
            }

            var fileName = Path.GetFileName(file.FileName);
            var employeeFolder = Path.Combine("wwwroot", "uploads", employeeId.ToString());

            // Create the employee-specific folder if it doesn't exist
            if (!Directory.Exists(employeeFolder))
            {
                Directory.CreateDirectory(employeeFolder);
            }

            var filePath = Path.Combine(employeeFolder, fileName);
            //  DateTime fileCreatedDate = File.GetCreationTime(filePath);
             lastModifiedDate = File.GetLastWriteTime(filePath);
            // Check if a file with the same name already exists
            var existingFile = await _db.EmployeeFiles.FirstOrDefaultAsync(e => e.FileName == fileName && e.EmployeeID == employeeId);

            if (existingFile != null)
            {
                // Delete the old file record and the associated file
                _db.EmployeeFiles.Remove(existingFile);
                await _db.SaveChangesAsync();
                File.Delete(existingFile.FilePath);
            }

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var employeeFile = new EmployeeFile
            {
                FileName = fileName,
                FilePath = filePath,
                FileCreatedDate = lastModifiedDate,
                EmployeeID = employeeId
            };

            _db.EmployeeFiles.Add(employeeFile);
            await _db.SaveChangesAsync();

            return true;
        }
        public T GetFirstOrDefault(Expression<Func<T, bool>> filter, string? includeProperties = null, bool tracked = true)
        {
            if (tracked)
            {
                IQueryable<T> query = dbSet;

                query = query.Where(filter);
                if (includeProperties != null)
                {
                    foreach (var includeProp in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        query = query.Include(includeProp);
                    }
                }
                return query.FirstOrDefault();
            }
            else
            {
                IQueryable<T> query = dbSet.AsNoTracking();

                query = query.Where(filter);
                if (includeProperties != null)
                {
                    foreach (var includeProp in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        query = query.Include(includeProp);
                    }
                }
                return query.FirstOrDefault();
            }
            
        }

        public void Remove(T entity)
        {
            dbSet.Remove(entity);
        }

        public void RemoveRange(IEnumerable<T> entity)
        {
            dbSet.RemoveRange(entity);
        }


        public async Task<FileUpload> GetByIdAsync(int id)
        {
            return await _db.FileUploads.FindAsync(id);
        }

        public async Task<IEnumerable<FileUpload>> GetAllAsync()
        {
            return await _db.FileUploads.ToListAsync();
        }

        public async Task AddAsync(FileUpload fileUpload)
        {
            _db.FileUploads.Add(fileUpload);
            await _db.SaveChangesAsync();
        }
        public async Task DeleteAsync(int id)
        {
            var fileUpload = await GetByIdAsync(id);
            if (fileUpload != null)
            {
                // Delete the file from the file system
                System.IO.File.Delete(fileUpload.FilePath);

                _db.FileUploads.Remove(fileUpload);
                await _db.SaveChangesAsync();
            }
        }
        public async Task UpdateStatusAsync(FileUpload fileUpload)
        {
            _db.FileUploads.Update(fileUpload);
            await _db.SaveChangesAsync();
        }
    }
}
