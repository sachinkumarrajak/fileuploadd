﻿using DataAccess.Data;
using DataAccess.Repository.IRepository;
using DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class iFileRepsotry : Repository<FileUpload>, Ifile
    {
        private ApplicationDbContext _db;

        public iFileRepsotry(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }


        public void Update(Ifile obj)
        {
           // _db.Ifile.Update(obj);
        }//

        public void Update(FileUpload obj)
        {
            //_db.FileUpload.Update(obj);
           // throw new NotImplementedException();
        }
    }
}
